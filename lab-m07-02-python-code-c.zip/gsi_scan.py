import boto3
from boto3.dynamodb.conditions import Key
def scan_username():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('students')

    resp = table.scan(
        IndexName='students2',


    )
    print(resp['Items'])

if __name__ == "__main__":
    scan_username()
