import boto3
from boto3.dynamodb.conditions import Key

def query_data_with_gsi():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('students')

    response = table.query(
      IndexName='students2',
      KeyConditionExpression = Key('locations').eq('Chicago'),
      FilterExpression = Key("fees").eq('paid')
    )

    print(response['Items'])

if __name__ == "__main__":
    query_data_with_gsi()