import boto3
from boto3.dynamodb.conditions import Key

def create_table_with_gsi():
    dynamodb = boto3.client('dynamodb')
    table = dynamodb.update_table(
        AttributeDefinitions=[
            {
                'AttributeName': 'locations',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'course',
                'AttributeType': 'S'
            },
        ],
        TableName='students',
        GlobalSecondaryIndexUpdates=[
            {
                'Create': {
                    'IndexName': 'students2',
                    'KeySchema': [
                        {
                            'AttributeName': 'locations',
                            'KeyType': 'HASH'
                        },
                        {
                            'AttributeName': 'course',
                            'KeyType': 'RANGE'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL'
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 1,
                        'WriteCapacityUnits': 1,
                    }
                }
            }
        ],
    )
    print("Created Sucessfully");


if __name__ == "__main__":
    create_table_with_gsi()