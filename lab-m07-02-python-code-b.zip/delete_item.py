import boto3
from botocore.exceptions import ClientError

def delete_user():
    dynamodb = boto3.resource('dynamodb')
    try:
        table = dynamodb.Table('students')

        table.delete_item(
            Key={
                'id': 2,
                'username': "Ahmad2"
            },
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Deleted sucessfully")

if __name__ == "__main__":
    delete_user()
