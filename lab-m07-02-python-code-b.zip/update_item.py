import boto3
from botocore.exceptions import ClientError

def update():
    dynamodb = boto3.resource('dynamodb')
    try:
        table = dynamodb.Table('students')
        table.update_item(
            Key={
                'id': 1,
                'username': "Ahmad1"
            },
            UpdateExpression="SET #ts = :val1",
            ExpressionAttributeValues={
                ':val1': "Hyderabad"
            },
            ExpressionAttributeNames={
                "#ts": "locations"
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Updated Sucessfully")

if __name__ == "__main__":
    update()