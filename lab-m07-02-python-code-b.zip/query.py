import boto3
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.conditions import Key

def query():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('students')
    firstname = "Ahmad1"
    resp = table.query(
        KeyConditionExpression=Key('id').eq(1),
        FilterExpression = Key("firstname").eq(firstname)
    )

    if 'Items' in resp:
        print(resp['Items'])

if __name__ == "__main__":
    query()