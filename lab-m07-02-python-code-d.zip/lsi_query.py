import boto3
from boto3.dynamodb.conditions import Key


def query_data_with_lsi():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('products')

    response = table.query(
        IndexName='store',
        KeyConditionExpression=
        Key('product_id').eq('p_1') & Key('store_location').eq('Delhi')
    )

    print(response['Items'])

if __name__ == "__main__":
    query_data_with_lsi()