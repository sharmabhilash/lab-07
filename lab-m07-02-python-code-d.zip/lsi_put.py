import boto3

def create_products():
    product1 = {
        'product_id': "p_1",
        'product_name': 'Keyboard',
        'product_qty': '71',
        'store_location': 'Delhi'
    }

    product2 = {
        'product_id': "p_2",
        'product_name': 'Keyboard',
        'product_qty': '38',
        'store_location': 'Mumbai'
    }

    product3 = {
        'product_id': "p_3",
        'product_name': 'Monitor',
        'product_qty': '17',
        'store_location': 'Delhi'
    }

    product4 = {
        'product_id': "p_4",
        'product_name': 'HDMI Cable',
        'product_qty': '210',
        'store_location': 'Mumbai'
    }

    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('products')

    table.put_item(Item=product1)
    table.put_item(Item=product2)
    table.put_item(Item=product3)
    table.put_item(Item=product4)

if __name__ == "__main__":
    create_products()