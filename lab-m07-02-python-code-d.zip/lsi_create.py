import boto3

def create_table_with_lsi():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.create_table(
        TableName='products',
        KeySchema=[
            {
                'AttributeName': 'product_id',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'product_name',
                'KeyType': 'RANGE'
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'product_id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'product_name',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'store_location',
                'AttributeType': 'S'
            },

        ],
        LocalSecondaryIndexes=[
            {
                'IndexName': 'store',
                'KeySchema': [
                    {
                        'AttributeName': 'product_id',
                        'KeyType': 'HASH'
                    },
                    {
                        'AttributeName': 'store_location',
                        'KeyType': 'RANGE'
                    },
                ],
                'Projection': {
                    'ProjectionType': 'ALL'
                },
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 1,
            'WriteCapacityUnits': 1,
        }
    )

    print("Table status:", table.table_status)

if __name__ == "__main__":
    create_table_with_lsi()