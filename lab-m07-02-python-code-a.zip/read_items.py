import boto3
from botocore.exceptions import ClientError

def get_item():
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('students')
    try:
        resp = table.get_item(
            Key={
                'id': 1,
                'username': "Ahmad1"
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if 'Item' in resp:
            print(resp['Item'])

if __name__ == "__main__":
    get_item()