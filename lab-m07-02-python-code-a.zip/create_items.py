import boto3
from botocore.exceptions import ClientError

def create_bunch_of_users():
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('students')
    try:
        for n in range(10):
            response = table.put_item(Item={
                'id': n,
                'username': "Ahmad" + str(n),
                'rollno': 'btc' + str(n),
                'firstname': "Ahmad" + str(n),
                'lastname': "Zahoory" + str(n),
                'locations': "Delhi",
                'course': "AWS"


            })
            print(response)
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Created sucessfully")

if __name__ == "__main__":
    create_bunch_of_users()
